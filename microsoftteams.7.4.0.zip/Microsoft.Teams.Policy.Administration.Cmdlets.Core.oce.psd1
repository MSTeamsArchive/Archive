#
# Module manifest for module 'Microsoft.Teams.Policy.Administration.Core'
#

@{
# Script module or binary module file associated with this manifest.
RootModule = './Microsoft.Teams.Policy.Administration.Cmdlets.Core.psm1'

# Version number of this module.
ModuleVersion = '21.4.4'

# Supported PSEditions
CompatiblePSEditions = 'Core', 'Desktop'

# ID used to uniquely identify this module
GUID = '048c99d9-471a-4935-a810-542687c5f950'

# Author of this module
Author = 'Microsoft Corporation'

# Company or vendor of this module
CompanyName = 'Microsoft Corporation'

# Copyright statement for this module
Copyright = 'Microsoft Corporation. All rights reserved.'

# Description of the functionality provided by this module
Description = 'Microsoft Teams OCE cmdlets module for Policy Administration'

# Minimum version of the Windows PowerShell engine required by this module
PowerShellVersion = '5.1'

# Name of the Windows PowerShell host required by this module
# PowerShellHostName = ''

# Minimum version of the Windows PowerShell host required by this module
# PowerShellHostVersion = ''

# Minimum version of Microsoft .NET Framework required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
DotNetFrameworkVersion = '4.7.2'

# Minimum version of the common language runtime (CLR) required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
CLRVersion = '4.0'

# Processor architecture (None, X86, Amd64) required by this module
# ProcessorArchitecture = 'Amd64'

# Modules that must be imported into the global environment prior to importing this module
# RequiredModules = @()

# Assemblies that must be loaded prior to importing this module
# RequiredAssemblies = @()

# Script files (.ps1) that are run in the caller's environment prior to importing this module.
# Removed this script from here because this module is used in SAW machines as well where Contraint Language Mode is on.
# Because of CLM constraint we were not able to import Teams module to SAW machines, that is why removing this script.
# ScriptsToProcess = @()

# Type files (.ps1xml) to be loaded when importing this module
# TypesToProcess = @()

# Format files (.ps1xml) to be loaded when importing this module
FormatsToProcess = @()

# Modules to import as nested modules of the module specified in RootModule/ModuleToProcess
NestedModules = @()

# Functions to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no functions to export.
FunctionsToExport = '*'

# Cmdlets to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no cmdlets to export.
CmdletsToExport = @(
    'New-CsTeamsAppSetupPolicy',
    'Get-CsTeamsAppSetupPolicy',
    'Remove-CsTeamsAppSetupPolicy',
    'Set-CsTeamsAppSetupPolicy',
    'Grant-CsTeamsAppSetupPolicy',


    'New-CsTeamsAppPermissionPolicy',
    'Get-CsTeamsAppPermissionPolicy',
    'Remove-CsTeamsAppPermissionPolicy',
    'Set-CsTeamsAppPermissionPolicy',
    'Grant-CsTeamsAppPermissionPolicy',

    'New-CsTeamsMessagingPolicy',
    'Set-CsTeamsMessagingPolicy',
    'Get-CsTeamsMessagingPolicy',
    'Remove-CsTeamsMessagingPolicy',

    'New-CsTeamsChannelsPolicy',
    'Get-CsTeamsChannelsPolicy',
    'Remove-CsTeamsChannelsPolicy',
    'Set-CsTeamsChannelsPolicy',

    'New-CsTeamsUpdateManagementPolicy',
    'Get-CsTeamsUpdateManagementPolicy',
    'Remove-CsTeamsUpdateManagementPolicy',
    'Set-CsTeamsUpdateManagementPolicy',

    'Get-CsTeamsUpgradeConfiguration',
    'Set-CsTeamsUpgradeConfiguration',

    'New-CsTeamsMeetingPolicy',
    'Get-CsTeamsMeetingPolicy',
    'Remove-CsTeamsMeetingPolicy',
    'Set-CsTeamsMeetingPolicy',

    'Get-CsOnlineVoicemailPolicy',
    'New-CsOnlineVoicemailPolicy',
    'Remove-CsOnlineVoicemailPolicy',
    'Set-CsOnlineVoicemailPolicy',

    'Get-CsOnlineVoicemailValidationConfiguration',
    'Set-CsOnlineVoicemailValidationConfiguration',

    'New-CsTeamsFeedbackPolicy',
    'Get-CsTeamsFeedbackPolicy',
    'Remove-CsTeamsFeedbackPolicy',
    'Set-CsTeamsFeedbackPolicy',

    'New-CsTeamsMeetingBrandingPolicy',
    'Get-CsTeamsMeetingBrandingPolicy',
    'Remove-CsTeamsMeetingBrandingPolicy',
    'Set-CsTeamsMeetingBrandingPolicy',
    'Grant-CsTeamsMeetingBrandingPolicy'

    'New-CsTeamsMeetingBrandingTheme',
    'New-CsTeamsMeetingBackgroundImage',
    'New-CsTeamsNdiAssuranceSlate',

    'New-CsTeamsEmergencyCallingPolicy',
    'Get-CsTeamsEmergencyCallingPolicy',
    'Remove-CsTeamsEmergencyCallingPolicy',
    'Set-CsTeamsEmergencyCallingPolicy',
    'New-CsTeamsEmergencyCallingExtendedNotification',

    'New-CsTeamsCallHoldPolicy',
    'Get-CsTeamsCallHoldPolicy',
    'Remove-CsTeamsCallHoldPolicy',
    'Set-CsTeamsCallHoldPolicy',

    'Get-CsOnlineVoicemailValidationConfiguration',
    'Set-CsOnlineVoicemailValidationConfiguration',
    'Get-CsTeamsMessagingConfiguration',
    'Set-CsTeamsMessagingConfiguration',

    'New-CsTeamsVoiceApplicationsPolicy',
    'Get-CsTeamsVoiceApplicationsPolicy',
    'Remove-CsTeamsVoiceApplicationsPolicy',
    'Set-CsTeamsVoiceApplicationsPolicy',

    'New-CsTeamsHiddenMeetingTemplate',

    'New-CsTeamsMeetingTemplatePermissionPolicy',
    'Get-CsTeamsMeetingTemplatePermissionPolicy',
    'Set-CsTeamsMeetingTemplatePermissionPolicy',
    'Remove-CsTeamsMeetingTemplatePermissionPolicy',
    'Grant-CsTeamsMeetingTemplatePermissionPolicy',

    "Get-CsTeamsAudioConferencingCustomPromptsConfiguration",
    "Set-CsTeamsAudioConferencingCustomPromptsConfiguration",
    "New-CsCustomPrompt",
    "New-CsCustomPromptPackage",

    'Get-CsTeamsMeetingTemplateConfiguration',
    'Get-CsTeamsFirstPartyMeetingTemplateConfiguration',

    'New-CsTeamsEventsPolicy',
    'Get-CsTeamsEventsPolicy',
    'Remove-CsTeamsEventsPolicy',
    'Set-CsTeamsEventsPolicy',
    'Grant-CsTeamsEventsPolicy',

    'New-CsTeamsCallingPolicy',
    'Get-CsTeamsCallingPolicy',
    'Remove-CsTeamsCallingPolicy',
    'Set-CsTeamsCallingPolicy',
    'Grant-CsTeamsCallingPolicy',

    'New-CsTeamsPersonalAttendantPolicy',
    'Get-CsTeamsPersonalAttendantPolicy',
    'Remove-CsTeamsPersonalAttendantPolicy',
    'Set-CsTeamsPersonalAttendantPolicy',
    'Grant-CsTeamsPersonalAttendantPolicy',

    'New-CsExternalAccessPolicy',
    'Get-CsExternalAccessPolicy',
    'Remove-CsExternalAccessPolicy',
    'Set-CsExternalAccessPolicy',
    'Grant-CsExternalAccessPolicy',

    'Get-CsTeamsMultiTenantOrganizationConfiguration',
    'Set-CsTeamsMultiTenantOrganizationConfiguration',

    'New-CsLocationPolicy',
    'Get-CsLocationPolicy',
    'Remove-CsLocationPolicy',
    'Set-CsLocationPolicy',

    'New-CsTeamsCarrierEmergencyCallRoutingPolicy',
    'Get-CsTeamsCarrierEmergencyCallRoutingPolicy',
    'Remove-CsTeamsCarrierEmergencyCallRoutingPolicy',
    'Set-CsTeamsCarrierEmergencyCallRoutingPolicy',
    'Grant-CsTeamsCarrierEmergencyCallRoutingPolicy',

    'Get-CsTenantConfiguration',
    'Set-CsTenantConfiguration',

    'Get-CsTenantNetworkSite',

    'New-CsTeamsShiftsPolicy',
    'Get-CsTeamsShiftsPolicy',
    'Remove-CsTeamsShiftsPolicy',
    'Set-CsTeamsShiftsPolicy',
    'Grant-CsTeamsShiftsPolicy',

    'New-CsTeamsHiddenTemplate',

    'New-CsTeamsTemplatePermissionPolicy',
    'Get-CsTeamsTemplatePermissionPolicy',
    'Remove-CsTeamsTemplatePermissionPolicy',
    'Set-CsTeamsTemplatePermissionPolicy',

    'Get-CsTeamsAppPolicyConfiguration',
    'Set-CsTeamsAppPolicyConfiguration',

    'Get-CsTeamsSipDevicesConfiguration',
    'Set-CsTeamsSipDevicesConfiguration',

    'New-CsTeamsVirtualAppointmentsPolicy',
    'Get-CsTeamsVirtualAppointmentsPolicy',
    'Remove-CsTeamsVirtualAppointmentsPolicy',
    'Set-CsTeamsVirtualAppointmentsPolicy',
    'Grant-CsTeamsVirtualAppointmentsPolicy',

    'New-CsTeamsComplianceRecordingPolicy',
    'Get-CsTeamsComplianceRecordingPolicy',
    'Remove-CsTeamsComplianceRecordingPolicy',
    'Set-CsTeamsComplianceRecordingPolicy',

    'New-CsTeamsComplianceRecordingApplication',
    'Get-CsTeamsComplianceRecordingApplication',
    'Remove-CsTeamsComplianceRecordingApplication',
    'Set-CsTeamsComplianceRecordingApplication',

    'New-CsTeamsComplianceRecordingPairedApplication',

    'New-CsTeamsSharedCallingRoutingPolicy',
    'Get-CsTeamsSharedCallingRoutingPolicy',
    'Remove-CsTeamsSharedCallingRoutingPolicy',
    'Set-CsTeamsSharedCallingRoutingPolicy',
    'Grant-CsTeamsSharedCallingRoutingPolicy',

    'New-CsTeamsVdiPolicy',
    'Get-CsTeamsVdiPolicy',
    'Remove-CsTeamsVdiPolicy',
    'Set-CsTeamsVdiPolicy',
    'Grant-CsTeamsVdiPolicy',

    'Get-CsTeamsMeetingConfiguration',
    'Set-CsTeamsMeetingConfiguration',

    'New-CsTeamsCustomBannerText',
    'Get-CsTeamsCustomBannerText',
    'Set-CsTeamsCustomBannerText',
    'Remove-CsTeamsCustomBannerText',
    
    'Get-CsTeamsEducationConfiguration',
    'Set-CsTeamsEducationConfiguration',

    'New-CsTeamsWorkLocationDetectionPolicy',
    'Get-CsTeamsWorkLocationDetectionPolicy',
    'Remove-CsTeamsWorkLocationDetectionPolicy',
    'Set-CsTeamsWorkLocationDetectionPolicy',
    'Grant-CsTeamsWorkLocationDetectionPolicy', 

    'New-CsTeamsMediaConnectivityPolicy',
    'Get-CsTeamsMediaConnectivityPolicy',
    'Remove-CsTeamsMediaConnectivityPolicy',
    'Set-CsTeamsMediaConnectivityPolicy',
    'Grant-CsTeamsMediaConnectivityPolicy',

    'New-CsTeamsRecordingRollOutPolicy',
    'Get-CsTeamsRecordingRollOutPolicy',
    'Remove-CsTeamsRecordingRollOutPolicy',
    'Set-CsTeamsRecordingRollOutPolicy',
    'Grant-CsTeamsRecordingRollOutPolicy',
	
	'New-CsTeamsFilesPolicy',
    'Get-CsTeamsFilesPolicy',
    'Remove-CsTeamsFilesPolicy',
    'Set-CsTeamsFilesPolicy',
    'Grant-CsTeamsFilesPolicy',
    
    'Get-CsTeamsExternalAccessConfiguration',
    'Set-CsTeamsExternalAccessConfiguration',

    'New-CsConversationRole',
    'Remove-CsConversationRole',
    'Get-CsConversationRole',
    'Set-CsConversationRole',

    'Get-CsConversationRolesSetting',
    'Set-CsConversationRolesSetting',

    'Get-CsTeamsAIPolicy',
    'Set-CsTeamsAIPolicy',
    'New-CsTeamsAIPolicy',
    'Remove-CsTeamsAIPolicy',
    'Grant-CsTeamsAIPolicy',

    'New-CsTeamsBYODAndDesksPolicy',
    'Get-CsTeamsBYODAndDesksPolicy',
    'Remove-CsTeamsBYODAndDesksPolicy',
    'Set-CsTeamsBYODAndDesksPolicy',
    'Grant-CsTeamsBYODAndDesksPolicy',

    'Get-CsTeamsTenantAbuseConfiguration',
    'Set-CsTeamsTenantAbuseConfiguration',

    'Get-CsTeamsEducationAssignmentsAppPolicy',
    'Set-CsTeamsEducationAssignmentsAppPolicy',

    'Get-CsPrivacyConfiguration',
    'Set-CsPrivacyConfiguration',

    'Get-CsTeamsNotificationAndFeedsPolicy',
    'Set-CsTeamsNotificationAndFeedsPolicy',
    'Remove-CsTeamsNotificationAndFeedsPolicy'
    
    'Get-CsTeamsClientConfiguration',
    'Set-CsTeamsClientConfiguration',
    
    'Get-CsTeamsAcsFederationConfiguration',
    'Set-CsTeamsAcsFederationConfiguration'
)

# Variables to export from this module
VariablesToExport = @()

# Aliases to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no aliases to export.
AliasesToExport = @()

# DSC resources to export from this module
# DscResourcesToExport = @()

# List of all modules packaged with this module
# ModuleList = @()

# List of all files packaged with this module
# FileList = @()

# Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
PrivateData = @{}

# HelpInfo URI of this module
# HelpInfoURI = ''

# Default prefix for commands exported from this module. Override the default prefix using Import-Module -Prefix.
# DefaultCommandPrefix = ''
}
# SIG # Begin signature block
# MIIoRgYJKoZIhvcNAQcCoIIoNzCCKDMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDDXuHz1JaXPYkJ
# QDhNbRvXPHHPibt4v/Y646nlvU08sqCCDXYwggX0MIID3KADAgECAhMzAAAEhV6Z
# 7A5ZL83XAAAAAASFMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM3WhcNMjYwNjE3MTgyMTM3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDASkh1cpvuUqfbqxele7LCSHEamVNBfFE4uY1FkGsAdUF/vnjpE1dnAD9vMOqy
# 5ZO49ILhP4jiP/P2Pn9ao+5TDtKmcQ+pZdzbG7t43yRXJC3nXvTGQroodPi9USQi
# 9rI+0gwuXRKBII7L+k3kMkKLmFrsWUjzgXVCLYa6ZH7BCALAcJWZTwWPoiT4HpqQ
# hJcYLB7pfetAVCeBEVZD8itKQ6QA5/LQR+9X6dlSj4Vxta4JnpxvgSrkjXCz+tlJ
# 67ABZ551lw23RWU1uyfgCfEFhBfiyPR2WSjskPl9ap6qrf8fNQ1sGYun2p4JdXxe
# UAKf1hVa/3TQXjvPTiRXCnJPAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuCZyGiCuLYE0aU7j5TFqY05kko0w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwNTM1OTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBACjmqAp2Ci4sTHZci+qk
# tEAKsFk5HNVGKyWR2rFGXsd7cggZ04H5U4SV0fAL6fOE9dLvt4I7HBHLhpGdE5Uj
# Ly4NxLTG2bDAkeAVmxmd2uKWVGKym1aarDxXfv3GCN4mRX+Pn4c+py3S/6Kkt5eS
# DAIIsrzKw3Kh2SW1hCwXX/k1v4b+NH1Fjl+i/xPJspXCFuZB4aC5FLT5fgbRKqns
# WeAdn8DsrYQhT3QXLt6Nv3/dMzv7G/Cdpbdcoul8FYl+t3dmXM+SIClC3l2ae0wO
# lNrQ42yQEycuPU5OoqLT85jsZ7+4CaScfFINlO7l7Y7r/xauqHbSPQ1r3oIC+e71
# 5s2G3ClZa3y99aYx2lnXYe1srcrIx8NAXTViiypXVn9ZGmEkfNcfDiqGQwkml5z9
# nm3pWiBZ69adaBBbAFEjyJG4y0a76bel/4sDCVvaZzLM3TFbxVO9BQrjZRtbJZbk
# C3XArpLqZSfx53SuYdddxPX8pvcqFuEu8wcUeD05t9xNbJ4TtdAECJlEi0vvBxlm
# M5tzFXy2qZeqPMXHSQYqPgZ9jvScZ6NwznFD0+33kbzyhOSz/WuGbAu4cHZG8gKn
# lQVT4uA2Diex9DMs2WHiokNknYlLoUeWXW1QrJLpqO82TLyKTbBM/oZHAdIc0kzo
# STro9b3+vjn2809D0+SOOCVZMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiYwghoiAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAASFXpnsDlkvzdcAAAAABIUwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBdiKccaQG4X/u061i5uhu0n
# Ywb27AT8bsv5He1eQ2r7MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAKuf/iSExCIw3oJlOtgwtA37Krdnwlp+UcXjIdx1TQwZylQYJqQVVQSqX
# F9TL1JkJLzxCJCAirAkdnbi9QFM9ta3LZWDeT7lJ+6wNwiHTnLh5b/GcOfA6ELiY
# oWDdRwxGtEnzUVm6AVKrJzy2dpE6j6gh+xfZfArdBH40PwwSu4nx4mNCLaiVA9KI
# UgjvhgPlBCC73fkpD+5HyYncGISj7cjFVw4rfUcVJyGUj1HkwTZ6QJHHUdS2rjaG
# 6OJpTMS2uVr/p9IxF33VpdFE8jGpTicuXUgShEqdDy0S0cmgVu3iGfxcYddbc0Gy
# DBcPBtTYmPXYAhQD81DlfcEK7KIogqGCF7AwghesBgorBgEEAYI3AwMBMYIXnDCC
# F5gGCSqGSIb3DQEHAqCCF4kwgheFAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBhv5RIaqJJyUFCk1NBe+Z7LNL5oc9PS5qo577DdQkVNwIGaKOvjL6J
# GBMyMDI1MTAwMTA4MzMwMi40ODZaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjoyQTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEf4wggcoMIIFEKADAgECAhMzAAAB+R9njXWrpPGxAAEAAAH5MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzEwOVoXDTI1MTAyMjE4MzEwOVowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjJBMUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtD1MH3yAHWHNVslC+CBT
# j/Mpd55LDPtQrhN7WeqFhReC9xKXSjobW1ZHzHU8V2BOJUiYg7fDJ2AxGVGyovUt
# gGZg2+GauFKk3ZjjsLSsqehYIsUQrgX+r/VATaW8/ONWy6lOyGZwZpxfV2EX4qAh
# 6mb2hadAuvdbRl1QK1tfBlR3fdeCBQG+ybz9JFZ45LN2ps8Nc1xr41N8Qi3KVJLY
# X0ibEbAkksR4bbszCzvY+vdSrjWyKAjR6YgYhaBaDxE2KDJ2sQRFFF/egCxKgogd
# F3VIJoCE/Wuy9MuEgypea1Hei7lFGvdLQZH5Jo2QR5uN8hiMc8Z47RRJuIWCOeyI
# J1YnRiiibpUZ72+wpv8LTov0yH6C5HR/D8+AT4vqtP57ITXsD9DPOob8tjtsefPc
# QJebUNiqyfyTL5j5/J+2d+GPCcXEYoeWZ+nrsZSfrd5DHM4ovCmD3lifgYnzjOry
# 4ghQT/cvmdHwFr6yJGphW/HG8GQd+cB4w7wGpOhHVJby44kGVK8MzY9s32Dy1THn
# Jg8p7y1sEGz/A1y84Zt6gIsITYaccHhBKp4cOVNrfoRVUx2G/0Tr7Dk3fpCU8u+5
# olqPPwKgZs57jl+lOrRVsX1AYEmAnyCyGrqRAzpGXyk1HvNIBpSNNuTBQk7FBvu+
# Ypi6A7S2V2Tj6lzYWVBvuGECAwEAAaOCAUkwggFFMB0GA1UdDgQWBBSJ7aO6nJXJ
# I9eijzS5QkR2RlngADAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAZiAJgFbkf7jf
# hx/mmZlnGZrpae+HGpxWxs8I79vUb8GQou50M1ns7iwG2CcdoXaq7VgpVkNf1uvI
# hrGYpKCBXQ+SaJ2O0BvwuJR7UsgTaKN0j/yf3fpHD0ktH+EkEuGXs9DBLyt71iut
# Vkwow9iQmSk4oIK8S8ArNGpSOzeuu9TdJjBjsasmuJ+2q5TjmrgEKyPe3TApAio8
# cdw/b1cBAmjtI7tpNYV5PyRI3K1NhuDgfEj5kynGF/uizP1NuHSxF/V1ks/2tCEo
# riicM4k1PJTTA0TCjNbkpmBcsAMlxTzBnWsqnBCt9d+Ud9Va3Iw9Bs4ccrkgBjLt
# g3vYGYar615ofYtU+dup+LuU0d2wBDEG1nhSWHaO+u2y6Si3AaNINt/pOMKU6l4A
# W0uDWUH39OHH3EqFHtTssZXaDOjtyRgbqMGmkf8KI3qIVBZJ2XQpnhEuRbh+Agpm
# Rn/a410Dk7VtPg2uC422WLC8H8IVk/FeoiSS4vFodhncFetJ0ZK36wxAa3FiPgBe
# bRWyVtZ763qDDzxDb0mB6HL9HEfTbN+4oHCkZa1HKl8B0s8RiFBMf/W7+O7EPZ+w
# MH8wdkjZ7SbsddtdRgRARqR8IFPWurQ+sn7ftEifaojzuCEahSAcq86yjwQeTPN9
# YG9b34RTurnkpD+wPGTB1WccMpsLlM0wggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDWTCCAkECAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjoyQTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAqs5WjWO7zVAKmIcdwhqgZvyp6UaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOyG2lkwIhgPMjAyNTA5MzAyMjM4MTdaGA8yMDI1MTAwMTIyMzgxN1owdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA7IbaWQIBADAKAgEAAgInWgIB/zAHAgEAAgIS
# RDAKAgUA7Igr2QIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQA0HygGCzYY
# EljnRjZKmlyq8BlFLyeDqjIsf+eW9udW0nwpYvks0ztwxcaklxi1JIufA2sghpxf
# O1DRxR/rkZvRt0N4b6+meKsltQSnJyY6A7LOg169vl4Ih4F80N3N244nRix969BP
# nYvMd94lXyhwLRk0vygjWuhF5VJIn+oJQ89bR2Qr+k1cEzI5Hypvq/WH0ZzZF7BS
# Pu2zhWTJrNuAefu02ATEKZh8YydBYJdQ9qT2SjXDDQoXxW6kWpyX51pxERwDxHfe
# YKGyp3xuGmIOtBT8jFD/bzNCUIAxAKYmggqdJI1IoRQOhyj/efZBnp2gn+TMH95Q
# 84INFZ6tWtSWMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAH5H2eNdauk8bEAAQAAAfkwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgdt9mntJj
# RBBWyP56rXOrvH2NmW5HQz5/jRtbgga5YPUwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCA5I4zIHvCN+2T66RUOLCZrUEVdoKlKl8VeCO5SbGLYEDCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB+R9njXWrpPGxAAEA
# AAH5MCIEIImoK59ZPcOXI5dNWhrN9BtaZ8YzydRxG6OcpV+4JnCfMA0GCSqGSIb3
# DQEBCwUABIICAFjI+sbIrIaktP9RfROriM1eSOHmoZ05V5eKCM48uBgqw1KEomYa
# d2cgcf0RVoKwNEl4X5t+DCIdzNFL30Hfw9WvPkcBuoiEisCL7edhiENRVEGYEqXg
# ACQj64vM7zwyP4IHiPJZmsp6QCzO2kMbzyBNUkR86nW76L/6D3WhAmdTkdZDaPSJ
# MR7ZSIQnM3UowGho2xJbb75nslbQuxFyafeePjS82nT5NIjXuMJZ/SBD95oXBG3U
# AGL8hMe5S5gL1+xlrQm88LBKj3GMUUNotJGHjpxbIeInCZDi63LPwp/AY/w2UOtN
# MbJXwZaiSglyHxzXD8fD3gewJElRz7oxwmw6n8hEEtyTwiC1npgOJIb03Ha1ziDs
# 0rKGbrWKPgs27vcI3QFnMhWVYx2M5SywMy5DBLGttnS0ZA0xfHHo9abRAw/oZ0X9
# mCub1465EFSW6l5ZxqGRfIDW0p9U5jKLeF9x4OP7vtMeaRz5/FlpC7cHhrJmD3uh
# xH5CZCK8p5/Rb7kD1kzf166XIB5Xt0Jdd8x900lANSY7wDuSaVWk7iWTfrzzOLiD
# nnPBoOEsGJ1hEEZlPIisXL04A4mkVxzsx7Rod8J8IgDXw9Zl8yqOt2Xh8F5zbXfB
# Ch5Yj/mLAW1CeMCNaTZHUKfmj54J+lnHmC7vXXiuVz/sdC71uegGlaMF
# SIG # End signature block
